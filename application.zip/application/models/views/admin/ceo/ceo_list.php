<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="card card-primary">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-10">
                            <h3 class="card-title">ম্যানেজ প্রধান নির্বাহী কর্মকর্তা</h3>
                        </div>
                        <div class="col-md-2 text-right">
                            <a href="<?php echo base_url(); ?>Admin/ceo_list_create" class="btn bg-olive">Add প্রধান নির্বাহী কর্মকর্তা</a>
                        </div>
                    </div>
                    
                </div>
                <div class="card-body">
                    <div class="row">
                            <div class="col-12">
                                <?php echo $this->session->flashdata('success') ?>
                            </div>
                        <div class="col-12">
                            <table class="table table-bordered">
                                <tr>
                                    <th class="align-middle text-center">অবস্থান</th>
                                    <th class="align-middle text-center">নাম</th>
                                    <th class="align-middle text-center">ছবি</th>
                                    <th class="align-middle text-center">প্রধান নির্বাহী কর্মকর্তার ধরন </th>
                                    <th class="align-middle text-center">কার্যকাল</th>
                                    <th class="align-middle text-center">Action</th>
                                </tr>
                                <?php if(!empty($ceos)) { 
                                    $count=0;
                                    foreach($ceos as $value){
                                        $count++;
                                    
                                    ?>
                                <tr>
                                    <td class="align-middle text-center"><?php echo $value->commitee; ?></td>
                                    <td class="align-middle text-center"><?php echo $value->title; ?></td>
                                    <td class="align-middle text-center"><img src="<?php echo base_url(); ?>/assets/uploads/photos/<?php echo $value->image; ?>" alt="Image" style="width:100px;height:100px;"></td>
                                    <td class="align-middle text-center"><?php echo $value->type; ?></td>
                                    <td class="align-middle text-center"><?php echo $value->time; ?></td>
                                    <td class="align-middle text-center">
                                        <div class="row">
                                            <div class="col-6">
                                                <form action="<?php echo base_url(); ?>Admin/ceo_list_edit" method="post">
                                                    <input type="hidden" name="id" value="<?php echo $value->id; ?>">
                                                    <button type="submit" class="custom_btn bg-info"><i class="fas fa-edit"></i></button>
                                                </form>
                                            </div>
                                            <div class="col-6">
                                                <form action="<?php echo base_url(); ?>Admin/ceo_list_detete" method="post">
                                                    <input type="hidden" name="id" value="<?php echo $value->id; ?>">
                                                    <input type="hidden" name="e_status" value="2">
                                                    <button type="submit" class="custom_btn bg-danger"><i class="fas fa-trash"></i></button>
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php } } ?>
                            </table>
                            <?= $this->pagination_bootstrap->render() ?>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>