<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2026-11-15 07:29:28 --> Config Class Initialized
INFO - 2026-11-15 07:29:28 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:29:28 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:29:28 --> Utf8 Class Initialized
INFO - 2026-11-15 07:29:28 --> URI Class Initialized
INFO - 2026-11-15 07:29:28 --> Router Class Initialized
INFO - 2026-11-15 07:29:28 --> Output Class Initialized
INFO - 2026-11-15 07:29:28 --> Security Class Initialized
DEBUG - 2026-11-15 07:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:29:28 --> Input Class Initialized
INFO - 2026-11-15 07:29:28 --> Language Class Initialized
INFO - 2026-11-15 07:29:28 --> Loader Class Initialized
INFO - 2026-11-15 07:29:28 --> Helper loaded: url_helper
INFO - 2026-11-15 07:29:28 --> Helper loaded: form_helper
INFO - 2026-11-15 07:29:28 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:29:28 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:29:28 --> Helper loaded: language_helper
INFO - 2026-11-15 07:29:28 --> Helper loaded: file_helper
INFO - 2026-11-15 07:29:28 --> Database Driver Class Initialized
INFO - 2026-11-15 07:29:28 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:29:28 --> Pagination Class Initialized
INFO - 2026-11-15 07:29:28 --> Model "Common" initialized
INFO - 2026-11-15 07:29:28 --> Controller Class Initialized
INFO - 2026-11-15 07:29:28 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:29:28 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_details.php
INFO - 2026-11-15 07:29:28 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:29:28 --> Final output sent to browser
DEBUG - 2026-11-15 07:29:28 --> Total execution time: 0.3094
INFO - 2026-11-15 07:30:24 --> Config Class Initialized
INFO - 2026-11-15 07:30:24 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:30:24 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:30:24 --> Utf8 Class Initialized
INFO - 2026-11-15 07:30:24 --> URI Class Initialized
INFO - 2026-11-15 07:30:24 --> Router Class Initialized
INFO - 2026-11-15 07:30:24 --> Output Class Initialized
INFO - 2026-11-15 07:30:24 --> Security Class Initialized
DEBUG - 2026-11-15 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:30:24 --> Input Class Initialized
INFO - 2026-11-15 07:30:24 --> Language Class Initialized
INFO - 2026-11-15 07:30:24 --> Loader Class Initialized
INFO - 2026-11-15 07:30:24 --> Helper loaded: url_helper
INFO - 2026-11-15 07:30:24 --> Helper loaded: form_helper
INFO - 2026-11-15 07:30:24 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:30:24 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:30:24 --> Helper loaded: language_helper
INFO - 2026-11-15 07:30:24 --> Helper loaded: file_helper
INFO - 2026-11-15 07:30:24 --> Database Driver Class Initialized
INFO - 2026-11-15 07:30:24 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:30:24 --> Pagination Class Initialized
INFO - 2026-11-15 07:30:24 --> Model "Common" initialized
INFO - 2026-11-15 07:30:24 --> Controller Class Initialized
INFO - 2026-11-15 07:30:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:30:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_list.php
INFO - 2026-11-15 07:30:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:30:24 --> Final output sent to browser
DEBUG - 2026-11-15 07:30:24 --> Total execution time: 0.2154
INFO - 2026-11-15 07:31:25 --> Config Class Initialized
INFO - 2026-11-15 07:31:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:31:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:31:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:31:25 --> URI Class Initialized
INFO - 2026-11-15 07:31:25 --> Router Class Initialized
INFO - 2026-11-15 07:31:25 --> Output Class Initialized
INFO - 2026-11-15 07:31:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:31:25 --> Input Class Initialized
INFO - 2026-11-15 07:31:25 --> Language Class Initialized
INFO - 2026-11-15 07:31:25 --> Loader Class Initialized
INFO - 2026-11-15 07:31:25 --> Helper loaded: url_helper
INFO - 2026-11-15 07:31:25 --> Helper loaded: form_helper
INFO - 2026-11-15 07:31:25 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:31:25 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:31:25 --> Helper loaded: language_helper
INFO - 2026-11-15 07:31:25 --> Helper loaded: file_helper
INFO - 2026-11-15 07:31:25 --> Database Driver Class Initialized
INFO - 2026-11-15 07:31:25 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:31:25 --> Pagination Class Initialized
INFO - 2026-11-15 07:31:25 --> Model "Common" initialized
INFO - 2026-11-15 07:31:25 --> Controller Class Initialized
INFO - 2026-11-15 07:31:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:31:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_list.php
INFO - 2026-11-15 07:31:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:31:26 --> Final output sent to browser
DEBUG - 2026-11-15 07:31:26 --> Total execution time: 0.2978
INFO - 2026-11-15 07:31:31 --> Config Class Initialized
INFO - 2026-11-15 07:31:31 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:31:31 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:31:31 --> Utf8 Class Initialized
INFO - 2026-11-15 07:31:31 --> URI Class Initialized
INFO - 2026-11-15 07:31:31 --> Router Class Initialized
INFO - 2026-11-15 07:31:31 --> Output Class Initialized
INFO - 2026-11-15 07:31:31 --> Security Class Initialized
DEBUG - 2026-11-15 07:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:31:31 --> Input Class Initialized
INFO - 2026-11-15 07:31:31 --> Language Class Initialized
INFO - 2026-11-15 07:31:31 --> Loader Class Initialized
INFO - 2026-11-15 07:31:31 --> Helper loaded: url_helper
INFO - 2026-11-15 07:31:31 --> Helper loaded: form_helper
INFO - 2026-11-15 07:31:31 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:31:31 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:31:31 --> Helper loaded: language_helper
INFO - 2026-11-15 07:31:31 --> Helper loaded: file_helper
INFO - 2026-11-15 07:31:31 --> Database Driver Class Initialized
INFO - 2026-11-15 07:31:31 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:31:31 --> Pagination Class Initialized
INFO - 2026-11-15 07:31:31 --> Model "Common" initialized
INFO - 2026-11-15 07:31:31 --> Controller Class Initialized
INFO - 2026-11-15 07:31:31 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:31:31 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/attendance/set_attendance.php
INFO - 2026-11-15 07:31:31 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:31:32 --> Final output sent to browser
DEBUG - 2026-11-15 07:31:32 --> Total execution time: 0.1693
INFO - 2026-11-15 07:31:32 --> Config Class Initialized
INFO - 2026-11-15 07:31:32 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:31:32 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:31:32 --> Utf8 Class Initialized
INFO - 2026-11-15 07:31:32 --> URI Class Initialized
INFO - 2026-11-15 07:31:32 --> Router Class Initialized
INFO - 2026-11-15 07:31:32 --> Output Class Initialized
INFO - 2026-11-15 07:31:32 --> Security Class Initialized
DEBUG - 2026-11-15 07:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:31:32 --> Input Class Initialized
INFO - 2026-11-15 07:31:32 --> Language Class Initialized
ERROR - 2026-11-15 07:31:32 --> 404 Page Not Found: Assets/backend
INFO - 2026-11-15 07:36:55 --> Config Class Initialized
INFO - 2026-11-15 07:36:55 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:36:55 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:36:55 --> Utf8 Class Initialized
INFO - 2026-11-15 07:36:55 --> URI Class Initialized
INFO - 2026-11-15 07:36:55 --> Router Class Initialized
INFO - 2026-11-15 07:36:55 --> Output Class Initialized
INFO - 2026-11-15 07:36:55 --> Security Class Initialized
DEBUG - 2026-11-15 07:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:36:55 --> Input Class Initialized
INFO - 2026-11-15 07:36:55 --> Language Class Initialized
INFO - 2026-11-15 07:36:55 --> Loader Class Initialized
INFO - 2026-11-15 07:36:55 --> Helper loaded: url_helper
INFO - 2026-11-15 07:36:55 --> Helper loaded: form_helper
INFO - 2026-11-15 07:36:55 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:36:55 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:36:55 --> Helper loaded: language_helper
INFO - 2026-11-15 07:36:55 --> Helper loaded: file_helper
INFO - 2026-11-15 07:36:55 --> Database Driver Class Initialized
INFO - 2026-11-15 07:36:55 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:36:55 --> Pagination Class Initialized
INFO - 2026-11-15 07:36:55 --> Model "Common" initialized
INFO - 2026-11-15 07:36:55 --> Controller Class Initialized
INFO - 2026-11-15 07:36:55 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:36:55 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/attendance/set_attendance.php
INFO - 2026-11-15 07:36:56 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:36:56 --> Final output sent to browser
DEBUG - 2026-11-15 07:36:56 --> Total execution time: 0.2558
INFO - 2026-11-15 07:38:07 --> Config Class Initialized
INFO - 2026-11-15 07:38:07 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:38:07 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:38:07 --> Utf8 Class Initialized
INFO - 2026-11-15 07:38:07 --> URI Class Initialized
INFO - 2026-11-15 07:38:07 --> Router Class Initialized
INFO - 2026-11-15 07:38:07 --> Output Class Initialized
INFO - 2026-11-15 07:38:07 --> Security Class Initialized
DEBUG - 2026-11-15 07:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:38:07 --> Input Class Initialized
INFO - 2026-11-15 07:38:07 --> Language Class Initialized
INFO - 2026-11-15 07:38:07 --> Loader Class Initialized
INFO - 2026-11-15 07:38:07 --> Helper loaded: url_helper
INFO - 2026-11-15 07:38:07 --> Helper loaded: form_helper
INFO - 2026-11-15 07:38:07 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:38:07 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:38:07 --> Helper loaded: language_helper
INFO - 2026-11-15 07:38:07 --> Helper loaded: file_helper
INFO - 2026-11-15 07:38:08 --> Database Driver Class Initialized
INFO - 2026-11-15 07:38:08 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:38:08 --> Pagination Class Initialized
INFO - 2026-11-15 07:38:08 --> Model "Common" initialized
INFO - 2026-11-15 07:38:08 --> Controller Class Initialized
INFO - 2026-11-15 07:38:08 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:38:08 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/attendance/set_attendance.php
INFO - 2026-11-15 07:38:08 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:38:08 --> Final output sent to browser
DEBUG - 2026-11-15 07:38:08 --> Total execution time: 0.1999
INFO - 2026-11-15 07:38:10 --> Config Class Initialized
INFO - 2026-11-15 07:38:10 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:38:10 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:38:10 --> Utf8 Class Initialized
INFO - 2026-11-15 07:38:10 --> URI Class Initialized
INFO - 2026-11-15 07:38:10 --> Router Class Initialized
INFO - 2026-11-15 07:38:10 --> Output Class Initialized
INFO - 2026-11-15 07:38:10 --> Security Class Initialized
DEBUG - 2026-11-15 07:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:38:10 --> Input Class Initialized
INFO - 2026-11-15 07:38:10 --> Language Class Initialized
INFO - 2026-11-15 07:38:10 --> Loader Class Initialized
INFO - 2026-11-15 07:38:10 --> Helper loaded: url_helper
INFO - 2026-11-15 07:38:10 --> Helper loaded: form_helper
INFO - 2026-11-15 07:38:10 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:38:10 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:38:10 --> Helper loaded: language_helper
INFO - 2026-11-15 07:38:11 --> Helper loaded: file_helper
INFO - 2026-11-15 07:38:11 --> Database Driver Class Initialized
INFO - 2026-11-15 07:38:11 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:38:11 --> Pagination Class Initialized
INFO - 2026-11-15 07:38:11 --> Model "Common" initialized
INFO - 2026-11-15 07:38:11 --> Controller Class Initialized
INFO - 2026-11-15 07:38:11 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:38:11 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:38:11 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:38:11 --> Final output sent to browser
DEBUG - 2026-11-15 07:38:11 --> Total execution time: 0.1415
INFO - 2026-11-15 07:38:11 --> Config Class Initialized
INFO - 2026-11-15 07:38:11 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:38:11 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:38:11 --> Utf8 Class Initialized
INFO - 2026-11-15 07:38:11 --> URI Class Initialized
INFO - 2026-11-15 07:38:11 --> Router Class Initialized
INFO - 2026-11-15 07:38:11 --> Output Class Initialized
INFO - 2026-11-15 07:38:11 --> Security Class Initialized
DEBUG - 2026-11-15 07:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:38:11 --> Input Class Initialized
INFO - 2026-11-15 07:38:11 --> Language Class Initialized
ERROR - 2026-11-15 07:38:11 --> 404 Page Not Found: Assets/dist
INFO - 2026-11-15 07:38:47 --> Config Class Initialized
INFO - 2026-11-15 07:38:47 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:38:47 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:38:47 --> Utf8 Class Initialized
INFO - 2026-11-15 07:38:47 --> URI Class Initialized
INFO - 2026-11-15 07:38:47 --> Router Class Initialized
INFO - 2026-11-15 07:38:47 --> Output Class Initialized
INFO - 2026-11-15 07:38:47 --> Security Class Initialized
DEBUG - 2026-11-15 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:38:47 --> Input Class Initialized
INFO - 2026-11-15 07:38:47 --> Language Class Initialized
ERROR - 2026-11-15 07:38:47 --> 404 Page Not Found: Update_user_profile/index
INFO - 2026-11-15 07:39:29 --> Config Class Initialized
INFO - 2026-11-15 07:39:29 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:39:29 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:39:29 --> Utf8 Class Initialized
INFO - 2026-11-15 07:39:29 --> URI Class Initialized
INFO - 2026-11-15 07:39:29 --> Router Class Initialized
INFO - 2026-11-15 07:39:29 --> Output Class Initialized
INFO - 2026-11-15 07:39:29 --> Security Class Initialized
DEBUG - 2026-11-15 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:39:29 --> Input Class Initialized
INFO - 2026-11-15 07:39:29 --> Language Class Initialized
ERROR - 2026-11-15 07:39:29 --> 404 Page Not Found: Update_user_profile/index
INFO - 2026-11-15 07:39:31 --> Config Class Initialized
INFO - 2026-11-15 07:39:31 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:39:31 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:39:31 --> Utf8 Class Initialized
INFO - 2026-11-15 07:39:31 --> URI Class Initialized
INFO - 2026-11-15 07:39:31 --> Router Class Initialized
INFO - 2026-11-15 07:39:31 --> Output Class Initialized
INFO - 2026-11-15 07:39:31 --> Security Class Initialized
DEBUG - 2026-11-15 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:39:31 --> Input Class Initialized
INFO - 2026-11-15 07:39:31 --> Language Class Initialized
INFO - 2026-11-15 07:39:31 --> Loader Class Initialized
INFO - 2026-11-15 07:39:31 --> Helper loaded: url_helper
INFO - 2026-11-15 07:39:31 --> Helper loaded: form_helper
INFO - 2026-11-15 07:39:31 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:39:31 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:39:31 --> Helper loaded: language_helper
INFO - 2026-11-15 07:39:31 --> Helper loaded: file_helper
INFO - 2026-11-15 07:39:31 --> Database Driver Class Initialized
INFO - 2026-11-15 07:39:31 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:39:31 --> Pagination Class Initialized
INFO - 2026-11-15 07:39:31 --> Model "Common" initialized
INFO - 2026-11-15 07:39:31 --> Controller Class Initialized
INFO - 2026-11-15 07:39:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:39:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:39:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:39:32 --> Final output sent to browser
DEBUG - 2026-11-15 07:39:32 --> Total execution time: 0.1773
INFO - 2026-11-15 07:40:33 --> Config Class Initialized
INFO - 2026-11-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:40:33 --> Utf8 Class Initialized
INFO - 2026-11-15 07:40:33 --> URI Class Initialized
INFO - 2026-11-15 07:40:33 --> Router Class Initialized
INFO - 2026-11-15 07:40:33 --> Output Class Initialized
INFO - 2026-11-15 07:40:33 --> Security Class Initialized
DEBUG - 2026-11-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:40:33 --> Input Class Initialized
INFO - 2026-11-15 07:40:33 --> Language Class Initialized
INFO - 2026-11-15 07:40:33 --> Loader Class Initialized
INFO - 2026-11-15 07:40:33 --> Helper loaded: url_helper
INFO - 2026-11-15 07:40:33 --> Helper loaded: form_helper
INFO - 2026-11-15 07:40:33 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:40:33 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:40:33 --> Helper loaded: language_helper
INFO - 2026-11-15 07:40:33 --> Helper loaded: file_helper
INFO - 2026-11-15 07:40:33 --> Database Driver Class Initialized
INFO - 2026-11-15 07:40:33 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:40:33 --> Pagination Class Initialized
INFO - 2026-11-15 07:40:33 --> Model "Common" initialized
INFO - 2026-11-15 07:40:33 --> Controller Class Initialized
INFO - 2026-11-15 07:40:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:40:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:40:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:40:33 --> Final output sent to browser
DEBUG - 2026-11-15 07:40:33 --> Total execution time: 0.3272
INFO - 2026-11-15 07:40:33 --> Config Class Initialized
INFO - 2026-11-15 07:40:33 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:40:33 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:40:33 --> Utf8 Class Initialized
INFO - 2026-11-15 07:40:33 --> URI Class Initialized
INFO - 2026-11-15 07:40:33 --> Router Class Initialized
INFO - 2026-11-15 07:40:33 --> Output Class Initialized
INFO - 2026-11-15 07:40:33 --> Security Class Initialized
DEBUG - 2026-11-15 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:40:33 --> Input Class Initialized
INFO - 2026-11-15 07:40:33 --> Language Class Initialized
ERROR - 2026-11-15 07:40:33 --> 404 Page Not Found: Assets/dist
INFO - 2026-11-15 07:41:05 --> Config Class Initialized
INFO - 2026-11-15 07:41:05 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:05 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:05 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:05 --> URI Class Initialized
INFO - 2026-11-15 07:41:05 --> Router Class Initialized
INFO - 2026-11-15 07:41:05 --> Output Class Initialized
INFO - 2026-11-15 07:41:05 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:05 --> Input Class Initialized
INFO - 2026-11-15 07:41:05 --> Language Class Initialized
INFO - 2026-11-15 07:41:05 --> Loader Class Initialized
INFO - 2026-11-15 07:41:05 --> Helper loaded: url_helper
INFO - 2026-11-15 07:41:05 --> Helper loaded: form_helper
INFO - 2026-11-15 07:41:05 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:41:05 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:41:05 --> Helper loaded: language_helper
INFO - 2026-11-15 07:41:05 --> Helper loaded: file_helper
INFO - 2026-11-15 07:41:05 --> Database Driver Class Initialized
INFO - 2026-11-15 07:41:05 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:41:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:41:05 --> Pagination Class Initialized
INFO - 2026-11-15 07:41:05 --> Model "Common" initialized
INFO - 2026-11-15 07:41:05 --> Controller Class Initialized
INFO - 2026-11-15 07:41:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:41:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:41:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:41:05 --> Final output sent to browser
DEBUG - 2026-11-15 07:41:05 --> Total execution time: 0.2119
INFO - 2026-11-15 07:41:05 --> Config Class Initialized
INFO - 2026-11-15 07:41:05 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:05 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:05 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:05 --> URI Class Initialized
INFO - 2026-11-15 07:41:05 --> Router Class Initialized
INFO - 2026-11-15 07:41:05 --> Output Class Initialized
INFO - 2026-11-15 07:41:05 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:05 --> Input Class Initialized
INFO - 2026-11-15 07:41:05 --> Language Class Initialized
ERROR - 2026-11-15 07:41:05 --> 404 Page Not Found: Assets/dist
INFO - 2026-11-15 07:41:25 --> Config Class Initialized
INFO - 2026-11-15 07:41:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:25 --> URI Class Initialized
INFO - 2026-11-15 07:41:25 --> Router Class Initialized
INFO - 2026-11-15 07:41:25 --> Output Class Initialized
INFO - 2026-11-15 07:41:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:25 --> Input Class Initialized
INFO - 2026-11-15 07:41:25 --> Language Class Initialized
INFO - 2026-11-15 07:41:25 --> Loader Class Initialized
INFO - 2026-11-15 07:41:25 --> Helper loaded: url_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: form_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: language_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: file_helper
INFO - 2026-11-15 07:41:25 --> Database Driver Class Initialized
INFO - 2026-11-15 07:41:25 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:41:25 --> Pagination Class Initialized
INFO - 2026-11-15 07:41:25 --> Model "Common" initialized
INFO - 2026-11-15 07:41:25 --> Controller Class Initialized
INFO - 2026-11-15 07:41:25 --> Upload Class Initialized
INFO - 2026-11-15 07:41:25 --> Config Class Initialized
INFO - 2026-11-15 07:41:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:25 --> URI Class Initialized
INFO - 2026-11-15 07:41:25 --> Router Class Initialized
INFO - 2026-11-15 07:41:25 --> Output Class Initialized
INFO - 2026-11-15 07:41:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:25 --> Input Class Initialized
INFO - 2026-11-15 07:41:25 --> Language Class Initialized
INFO - 2026-11-15 07:41:25 --> Loader Class Initialized
INFO - 2026-11-15 07:41:25 --> Helper loaded: url_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: form_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: language_helper
INFO - 2026-11-15 07:41:25 --> Helper loaded: file_helper
INFO - 2026-11-15 07:41:25 --> Database Driver Class Initialized
INFO - 2026-11-15 07:41:25 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:41:25 --> Pagination Class Initialized
INFO - 2026-11-15 07:41:25 --> Model "Common" initialized
INFO - 2026-11-15 07:41:25 --> Controller Class Initialized
INFO - 2026-11-15 07:41:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:41:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:41:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:41:25 --> Final output sent to browser
DEBUG - 2026-11-15 07:41:25 --> Total execution time: 0.1636
INFO - 2026-11-15 07:41:25 --> Config Class Initialized
INFO - 2026-11-15 07:41:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:25 --> URI Class Initialized
INFO - 2026-11-15 07:41:25 --> Router Class Initialized
INFO - 2026-11-15 07:41:25 --> Output Class Initialized
INFO - 2026-11-15 07:41:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:25 --> Input Class Initialized
INFO - 2026-11-15 07:41:25 --> Language Class Initialized
ERROR - 2026-11-15 07:41:25 --> 404 Page Not Found: Assets/uploads
INFO - 2026-11-15 07:41:43 --> Config Class Initialized
INFO - 2026-11-15 07:41:43 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:43 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:43 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:43 --> URI Class Initialized
INFO - 2026-11-15 07:41:43 --> Router Class Initialized
INFO - 2026-11-15 07:41:43 --> Output Class Initialized
INFO - 2026-11-15 07:41:43 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:43 --> Input Class Initialized
INFO - 2026-11-15 07:41:43 --> Language Class Initialized
INFO - 2026-11-15 07:41:43 --> Loader Class Initialized
INFO - 2026-11-15 07:41:43 --> Helper loaded: url_helper
INFO - 2026-11-15 07:41:43 --> Helper loaded: form_helper
INFO - 2026-11-15 07:41:43 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:41:43 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:41:43 --> Helper loaded: language_helper
INFO - 2026-11-15 07:41:43 --> Helper loaded: file_helper
INFO - 2026-11-15 07:41:43 --> Database Driver Class Initialized
INFO - 2026-11-15 07:41:43 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:41:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:41:43 --> Pagination Class Initialized
INFO - 2026-11-15 07:41:43 --> Model "Common" initialized
INFO - 2026-11-15 07:41:43 --> Controller Class Initialized
INFO - 2026-11-15 07:41:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:41:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:41:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:41:43 --> Final output sent to browser
DEBUG - 2026-11-15 07:41:43 --> Total execution time: 0.1834
INFO - 2026-11-15 07:41:53 --> Config Class Initialized
INFO - 2026-11-15 07:41:53 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:41:53 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:41:53 --> Utf8 Class Initialized
INFO - 2026-11-15 07:41:53 --> URI Class Initialized
INFO - 2026-11-15 07:41:53 --> Router Class Initialized
INFO - 2026-11-15 07:41:53 --> Output Class Initialized
INFO - 2026-11-15 07:41:53 --> Security Class Initialized
DEBUG - 2026-11-15 07:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:41:53 --> Input Class Initialized
INFO - 2026-11-15 07:41:53 --> Language Class Initialized
INFO - 2026-11-15 07:41:53 --> Loader Class Initialized
INFO - 2026-11-15 07:41:53 --> Helper loaded: url_helper
INFO - 2026-11-15 07:41:53 --> Helper loaded: form_helper
INFO - 2026-11-15 07:41:53 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:41:53 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:41:53 --> Helper loaded: language_helper
INFO - 2026-11-15 07:41:53 --> Helper loaded: file_helper
INFO - 2026-11-15 07:41:53 --> Database Driver Class Initialized
INFO - 2026-11-15 07:41:53 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:41:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:41:53 --> Pagination Class Initialized
INFO - 2026-11-15 07:41:53 --> Model "Common" initialized
INFO - 2026-11-15 07:41:53 --> Controller Class Initialized
INFO - 2026-11-15 07:41:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:41:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:41:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:41:53 --> Final output sent to browser
DEBUG - 2026-11-15 07:41:54 --> Total execution time: 0.1841
INFO - 2026-11-15 07:42:31 --> Config Class Initialized
INFO - 2026-11-15 07:42:31 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:42:31 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:42:31 --> Utf8 Class Initialized
INFO - 2026-11-15 07:42:31 --> URI Class Initialized
INFO - 2026-11-15 07:42:31 --> Router Class Initialized
INFO - 2026-11-15 07:42:31 --> Output Class Initialized
INFO - 2026-11-15 07:42:31 --> Security Class Initialized
DEBUG - 2026-11-15 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:42:31 --> Input Class Initialized
INFO - 2026-11-15 07:42:31 --> Language Class Initialized
INFO - 2026-11-15 07:42:31 --> Loader Class Initialized
INFO - 2026-11-15 07:42:31 --> Helper loaded: url_helper
INFO - 2026-11-15 07:42:31 --> Helper loaded: form_helper
INFO - 2026-11-15 07:42:31 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:42:31 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:42:31 --> Helper loaded: language_helper
INFO - 2026-11-15 07:42:31 --> Helper loaded: file_helper
INFO - 2026-11-15 07:42:31 --> Database Driver Class Initialized
INFO - 2026-11-15 07:42:31 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:42:31 --> Pagination Class Initialized
INFO - 2026-11-15 07:42:31 --> Model "Common" initialized
INFO - 2026-11-15 07:42:31 --> Controller Class Initialized
INFO - 2026-11-15 07:42:31 --> Upload Class Initialized
DEBUG - 2026-11-15 07:42:31 --> Upload class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:42:32 --> Config Class Initialized
INFO - 2026-11-15 07:42:32 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:42:32 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:42:32 --> Utf8 Class Initialized
INFO - 2026-11-15 07:42:32 --> URI Class Initialized
INFO - 2026-11-15 07:42:32 --> Router Class Initialized
INFO - 2026-11-15 07:42:32 --> Output Class Initialized
INFO - 2026-11-15 07:42:32 --> Security Class Initialized
DEBUG - 2026-11-15 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:42:32 --> Input Class Initialized
INFO - 2026-11-15 07:42:32 --> Language Class Initialized
INFO - 2026-11-15 07:42:32 --> Loader Class Initialized
INFO - 2026-11-15 07:42:32 --> Helper loaded: url_helper
INFO - 2026-11-15 07:42:32 --> Helper loaded: form_helper
INFO - 2026-11-15 07:42:32 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:42:32 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:42:32 --> Helper loaded: language_helper
INFO - 2026-11-15 07:42:32 --> Helper loaded: file_helper
INFO - 2026-11-15 07:42:32 --> Database Driver Class Initialized
INFO - 2026-11-15 07:42:32 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:42:32 --> Pagination Class Initialized
INFO - 2026-11-15 07:42:32 --> Model "Common" initialized
INFO - 2026-11-15 07:42:32 --> Controller Class Initialized
INFO - 2026-11-15 07:42:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:42:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:42:32 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:42:32 --> Final output sent to browser
DEBUG - 2026-11-15 07:42:32 --> Total execution time: 0.1679
INFO - 2026-11-15 07:42:40 --> Config Class Initialized
INFO - 2026-11-15 07:42:40 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:42:40 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:42:40 --> Utf8 Class Initialized
INFO - 2026-11-15 07:42:40 --> URI Class Initialized
INFO - 2026-11-15 07:42:40 --> Router Class Initialized
INFO - 2026-11-15 07:42:40 --> Output Class Initialized
INFO - 2026-11-15 07:42:40 --> Security Class Initialized
DEBUG - 2026-11-15 07:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:42:40 --> Input Class Initialized
INFO - 2026-11-15 07:42:40 --> Language Class Initialized
INFO - 2026-11-15 07:42:40 --> Loader Class Initialized
INFO - 2026-11-15 07:42:40 --> Helper loaded: url_helper
INFO - 2026-11-15 07:42:40 --> Helper loaded: form_helper
INFO - 2026-11-15 07:42:40 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:42:40 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:42:40 --> Helper loaded: language_helper
INFO - 2026-11-15 07:42:40 --> Helper loaded: file_helper
INFO - 2026-11-15 07:42:40 --> Database Driver Class Initialized
INFO - 2026-11-15 07:42:40 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:42:40 --> Pagination Class Initialized
INFO - 2026-11-15 07:42:40 --> Model "Common" initialized
INFO - 2026-11-15 07:42:40 --> Controller Class Initialized
INFO - 2026-11-15 07:42:40 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:42:40 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:42:40 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:42:40 --> Final output sent to browser
DEBUG - 2026-11-15 07:42:40 --> Total execution time: 0.1864
INFO - 2026-11-15 07:43:22 --> Config Class Initialized
INFO - 2026-11-15 07:43:22 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:43:22 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:43:22 --> Utf8 Class Initialized
INFO - 2026-11-15 07:43:22 --> URI Class Initialized
INFO - 2026-11-15 07:43:22 --> Router Class Initialized
INFO - 2026-11-15 07:43:22 --> Output Class Initialized
INFO - 2026-11-15 07:43:22 --> Security Class Initialized
DEBUG - 2026-11-15 07:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:43:22 --> Input Class Initialized
INFO - 2026-11-15 07:43:23 --> Language Class Initialized
INFO - 2026-11-15 07:43:23 --> Loader Class Initialized
INFO - 2026-11-15 07:43:23 --> Helper loaded: url_helper
INFO - 2026-11-15 07:43:23 --> Helper loaded: form_helper
INFO - 2026-11-15 07:43:23 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:43:23 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:43:23 --> Helper loaded: language_helper
INFO - 2026-11-15 07:43:23 --> Helper loaded: file_helper
INFO - 2026-11-15 07:43:23 --> Database Driver Class Initialized
INFO - 2026-11-15 07:43:23 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:43:23 --> Pagination Class Initialized
INFO - 2026-11-15 07:43:23 --> Model "Common" initialized
INFO - 2026-11-15 07:43:23 --> Controller Class Initialized
INFO - 2026-11-15 07:43:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:43:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:43:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:43:23 --> Final output sent to browser
DEBUG - 2026-11-15 07:43:23 --> Total execution time: 0.2785
INFO - 2026-11-15 07:44:37 --> Config Class Initialized
INFO - 2026-11-15 07:44:37 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:44:37 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:44:37 --> Utf8 Class Initialized
INFO - 2026-11-15 07:44:37 --> URI Class Initialized
INFO - 2026-11-15 07:44:37 --> Router Class Initialized
INFO - 2026-11-15 07:44:37 --> Output Class Initialized
INFO - 2026-11-15 07:44:37 --> Security Class Initialized
DEBUG - 2026-11-15 07:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:44:37 --> Input Class Initialized
INFO - 2026-11-15 07:44:37 --> Language Class Initialized
INFO - 2026-11-15 07:44:37 --> Loader Class Initialized
INFO - 2026-11-15 07:44:37 --> Helper loaded: url_helper
INFO - 2026-11-15 07:44:37 --> Helper loaded: form_helper
INFO - 2026-11-15 07:44:37 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:44:37 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:44:37 --> Helper loaded: language_helper
INFO - 2026-11-15 07:44:37 --> Helper loaded: file_helper
INFO - 2026-11-15 07:44:37 --> Database Driver Class Initialized
INFO - 2026-11-15 07:44:37 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:44:37 --> Pagination Class Initialized
INFO - 2026-11-15 07:44:37 --> Model "Common" initialized
INFO - 2026-11-15 07:44:37 --> Controller Class Initialized
INFO - 2026-11-15 07:44:37 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:44:37 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:44:37 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:44:37 --> Final output sent to browser
DEBUG - 2026-11-15 07:44:37 --> Total execution time: 0.2048
INFO - 2026-11-15 07:45:08 --> Config Class Initialized
INFO - 2026-11-15 07:45:08 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:45:08 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:45:08 --> Utf8 Class Initialized
INFO - 2026-11-15 07:45:08 --> URI Class Initialized
INFO - 2026-11-15 07:45:08 --> Router Class Initialized
INFO - 2026-11-15 07:45:08 --> Output Class Initialized
INFO - 2026-11-15 07:45:08 --> Security Class Initialized
DEBUG - 2026-11-15 07:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:45:08 --> Input Class Initialized
INFO - 2026-11-15 07:45:08 --> Language Class Initialized
INFO - 2026-11-15 07:45:08 --> Loader Class Initialized
INFO - 2026-11-15 07:45:09 --> Helper loaded: url_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: form_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: language_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: file_helper
INFO - 2026-11-15 07:45:09 --> Database Driver Class Initialized
INFO - 2026-11-15 07:45:09 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:45:09 --> Pagination Class Initialized
INFO - 2026-11-15 07:45:09 --> Model "Common" initialized
INFO - 2026-11-15 07:45:09 --> Controller Class Initialized
INFO - 2026-11-15 07:45:09 --> Config Class Initialized
INFO - 2026-11-15 07:45:09 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:45:09 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:45:09 --> Utf8 Class Initialized
INFO - 2026-11-15 07:45:09 --> URI Class Initialized
INFO - 2026-11-15 07:45:09 --> Router Class Initialized
INFO - 2026-11-15 07:45:09 --> Output Class Initialized
INFO - 2026-11-15 07:45:09 --> Security Class Initialized
DEBUG - 2026-11-15 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:45:09 --> Input Class Initialized
INFO - 2026-11-15 07:45:09 --> Language Class Initialized
INFO - 2026-11-15 07:45:09 --> Loader Class Initialized
INFO - 2026-11-15 07:45:09 --> Helper loaded: url_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: form_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: language_helper
INFO - 2026-11-15 07:45:09 --> Helper loaded: file_helper
INFO - 2026-11-15 07:45:09 --> Database Driver Class Initialized
INFO - 2026-11-15 07:45:09 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:45:09 --> Pagination Class Initialized
INFO - 2026-11-15 07:45:09 --> Model "Common" initialized
INFO - 2026-11-15 07:45:09 --> Controller Class Initialized
INFO - 2026-11-15 07:45:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:45:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:45:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:45:09 --> Final output sent to browser
DEBUG - 2026-11-15 07:45:09 --> Total execution time: 0.1569
INFO - 2026-11-15 07:45:51 --> Config Class Initialized
INFO - 2026-11-15 07:45:51 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:45:51 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:45:51 --> Utf8 Class Initialized
INFO - 2026-11-15 07:45:51 --> URI Class Initialized
INFO - 2026-11-15 07:45:51 --> Router Class Initialized
INFO - 2026-11-15 07:45:51 --> Output Class Initialized
INFO - 2026-11-15 07:45:51 --> Security Class Initialized
DEBUG - 2026-11-15 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:45:51 --> Input Class Initialized
INFO - 2026-11-15 07:45:51 --> Language Class Initialized
INFO - 2026-11-15 07:45:51 --> Loader Class Initialized
INFO - 2026-11-15 07:45:51 --> Helper loaded: url_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: form_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: language_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: file_helper
INFO - 2026-11-15 07:45:51 --> Database Driver Class Initialized
INFO - 2026-11-15 07:45:51 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:45:51 --> Pagination Class Initialized
INFO - 2026-11-15 07:45:51 --> Model "Common" initialized
INFO - 2026-11-15 07:45:51 --> Controller Class Initialized
INFO - 2026-11-15 07:45:51 --> Config Class Initialized
INFO - 2026-11-15 07:45:51 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:45:51 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:45:51 --> Utf8 Class Initialized
INFO - 2026-11-15 07:45:51 --> URI Class Initialized
INFO - 2026-11-15 07:45:51 --> Router Class Initialized
INFO - 2026-11-15 07:45:51 --> Output Class Initialized
INFO - 2026-11-15 07:45:51 --> Security Class Initialized
DEBUG - 2026-11-15 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:45:51 --> Input Class Initialized
INFO - 2026-11-15 07:45:51 --> Language Class Initialized
INFO - 2026-11-15 07:45:51 --> Loader Class Initialized
INFO - 2026-11-15 07:45:51 --> Helper loaded: url_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: form_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: language_helper
INFO - 2026-11-15 07:45:51 --> Helper loaded: file_helper
INFO - 2026-11-15 07:45:51 --> Database Driver Class Initialized
INFO - 2026-11-15 07:45:51 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:45:51 --> Pagination Class Initialized
INFO - 2026-11-15 07:45:51 --> Model "Common" initialized
INFO - 2026-11-15 07:45:51 --> Controller Class Initialized
INFO - 2026-11-15 07:45:52 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 07:45:52 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/users_list/users_profile.php
INFO - 2026-11-15 07:45:52 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 07:45:52 --> Final output sent to browser
DEBUG - 2026-11-15 07:45:52 --> Total execution time: 0.1553
INFO - 2026-11-15 07:46:45 --> Config Class Initialized
INFO - 2026-11-15 07:46:46 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:46:46 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:46:46 --> Utf8 Class Initialized
INFO - 2026-11-15 07:46:46 --> URI Class Initialized
INFO - 2026-11-15 07:46:46 --> Router Class Initialized
INFO - 2026-11-15 07:46:46 --> Output Class Initialized
INFO - 2026-11-15 07:46:46 --> Security Class Initialized
DEBUG - 2026-11-15 07:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:46:46 --> Input Class Initialized
INFO - 2026-11-15 07:46:46 --> Language Class Initialized
INFO - 2026-11-15 07:46:46 --> Loader Class Initialized
INFO - 2026-11-15 07:46:46 --> Helper loaded: url_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: form_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: language_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: file_helper
INFO - 2026-11-15 07:46:46 --> Database Driver Class Initialized
INFO - 2026-11-15 07:46:46 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:46:46 --> Pagination Class Initialized
INFO - 2026-11-15 07:46:46 --> Model "Common" initialized
INFO - 2026-11-15 07:46:46 --> Controller Class Initialized
INFO - 2026-11-15 07:46:46 --> Config Class Initialized
INFO - 2026-11-15 07:46:46 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:46:46 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:46:46 --> Utf8 Class Initialized
INFO - 2026-11-15 07:46:46 --> URI Class Initialized
INFO - 2026-11-15 07:46:46 --> Router Class Initialized
INFO - 2026-11-15 07:46:46 --> Output Class Initialized
INFO - 2026-11-15 07:46:46 --> Security Class Initialized
DEBUG - 2026-11-15 07:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:46:46 --> Input Class Initialized
INFO - 2026-11-15 07:46:46 --> Language Class Initialized
INFO - 2026-11-15 07:46:46 --> Loader Class Initialized
INFO - 2026-11-15 07:46:46 --> Helper loaded: url_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: form_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: language_helper
INFO - 2026-11-15 07:46:46 --> Helper loaded: file_helper
INFO - 2026-11-15 07:46:46 --> Database Driver Class Initialized
INFO - 2026-11-15 07:46:46 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:46:46 --> Pagination Class Initialized
INFO - 2026-11-15 07:46:46 --> Model "Common" initialized
INFO - 2026-11-15 07:46:46 --> Controller Class Initialized
INFO - 2026-11-15 07:46:46 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/header.php
INFO - 2026-11-15 07:46:46 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/footer.php
INFO - 2026-11-15 07:46:46 --> File loaded: C:\xampp\htdocs\ctl3\application\views\login/login.php
INFO - 2026-11-15 07:46:46 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/master_layout.php
INFO - 2026-11-15 07:46:46 --> Final output sent to browser
DEBUG - 2026-11-15 07:46:46 --> Total execution time: 0.1212
INFO - 2026-11-15 07:46:58 --> Config Class Initialized
INFO - 2026-11-15 07:46:58 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:46:58 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:46:58 --> Utf8 Class Initialized
INFO - 2026-11-15 07:46:58 --> URI Class Initialized
INFO - 2026-11-15 07:46:58 --> Router Class Initialized
INFO - 2026-11-15 07:46:58 --> Output Class Initialized
INFO - 2026-11-15 07:46:58 --> Security Class Initialized
DEBUG - 2026-11-15 07:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:46:58 --> Input Class Initialized
INFO - 2026-11-15 07:46:58 --> Language Class Initialized
ERROR - 2026-11-15 07:46:58 --> 404 Page Not Found: Staff_zone/index
INFO - 2026-11-15 07:47:03 --> Config Class Initialized
INFO - 2026-11-15 07:47:03 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:03 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:03 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:03 --> URI Class Initialized
INFO - 2026-11-15 07:47:03 --> Router Class Initialized
INFO - 2026-11-15 07:47:03 --> Output Class Initialized
INFO - 2026-11-15 07:47:03 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:03 --> Input Class Initialized
INFO - 2026-11-15 07:47:03 --> Language Class Initialized
INFO - 2026-11-15 07:47:03 --> Loader Class Initialized
INFO - 2026-11-15 07:47:03 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:03 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:03 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:03 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:03 --> Model "Common" initialized
INFO - 2026-11-15 07:47:03 --> Controller Class Initialized
INFO - 2026-11-15 07:47:03 --> Config Class Initialized
INFO - 2026-11-15 07:47:03 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:03 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:03 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:03 --> URI Class Initialized
INFO - 2026-11-15 07:47:03 --> Router Class Initialized
INFO - 2026-11-15 07:47:03 --> Output Class Initialized
INFO - 2026-11-15 07:47:03 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:03 --> Input Class Initialized
INFO - 2026-11-15 07:47:03 --> Language Class Initialized
INFO - 2026-11-15 07:47:03 --> Loader Class Initialized
INFO - 2026-11-15 07:47:03 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:03 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:03 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:03 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:03 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:03 --> Model "Common" initialized
INFO - 2026-11-15 07:47:03 --> Controller Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Session class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:47:03 --> Language file loaded: language/bangla/site_lang.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/home_page_header.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/navbar.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/news_headline.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/header.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/footer.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/user_registration/user_login_form.php
INFO - 2026-11-15 07:47:03 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/master_layout.php
INFO - 2026-11-15 07:47:03 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:03 --> Total execution time: 0.1606
INFO - 2026-11-15 07:47:03 --> Config Class Initialized
INFO - 2026-11-15 07:47:03 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:03 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:03 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:03 --> URI Class Initialized
INFO - 2026-11-15 07:47:03 --> Router Class Initialized
INFO - 2026-11-15 07:47:03 --> Output Class Initialized
INFO - 2026-11-15 07:47:03 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:03 --> Input Class Initialized
INFO - 2026-11-15 07:47:03 --> Language Class Initialized
ERROR - 2026-11-15 07:47:03 --> 404 Page Not Found: Stylecss/index
INFO - 2026-11-15 07:47:06 --> Config Class Initialized
INFO - 2026-11-15 07:47:06 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:06 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:06 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:06 --> URI Class Initialized
INFO - 2026-11-15 07:47:06 --> Router Class Initialized
INFO - 2026-11-15 07:47:06 --> Output Class Initialized
INFO - 2026-11-15 07:47:06 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:06 --> Input Class Initialized
INFO - 2026-11-15 07:47:06 --> Language Class Initialized
INFO - 2026-11-15 07:47:06 --> Loader Class Initialized
INFO - 2026-11-15 07:47:06 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:06 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:06 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:06 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:06 --> Model "Common" initialized
INFO - 2026-11-15 07:47:06 --> Controller Class Initialized
DEBUG - 2026-11-15 07:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:47:06 --> Language file loaded: language/bangla/site_lang.php
INFO - 2026-11-15 07:47:06 --> Config Class Initialized
INFO - 2026-11-15 07:47:06 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:06 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:06 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:06 --> URI Class Initialized
INFO - 2026-11-15 07:47:06 --> Router Class Initialized
INFO - 2026-11-15 07:47:06 --> Output Class Initialized
INFO - 2026-11-15 07:47:06 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:06 --> Input Class Initialized
INFO - 2026-11-15 07:47:06 --> Language Class Initialized
INFO - 2026-11-15 07:47:06 --> Loader Class Initialized
INFO - 2026-11-15 07:47:06 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:06 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:06 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:06 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:06 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:06 --> Model "Common" initialized
INFO - 2026-11-15 07:47:06 --> Controller Class Initialized
INFO - 2026-11-15 07:47:06 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 12:47:06 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence_portal.php
INFO - 2026-11-15 12:47:06 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/profile_update_portal.php
INFO - 2026-11-15 12:47:06 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/dashboard.php
INFO - 2026-11-15 12:47:06 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 12:47:06 --> Final output sent to browser
DEBUG - 2026-11-15 12:47:06 --> Total execution time: 0.1609
INFO - 2026-11-15 07:47:13 --> Config Class Initialized
INFO - 2026-11-15 07:47:13 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:13 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:13 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:13 --> URI Class Initialized
INFO - 2026-11-15 07:47:13 --> Router Class Initialized
INFO - 2026-11-15 07:47:13 --> Output Class Initialized
INFO - 2026-11-15 07:47:13 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:13 --> Input Class Initialized
INFO - 2026-11-15 07:47:13 --> Language Class Initialized
INFO - 2026-11-15 07:47:14 --> Loader Class Initialized
INFO - 2026-11-15 07:47:14 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:14 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:14 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:14 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:14 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:14 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:14 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:14 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:14 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:14 --> Model "Common" initialized
INFO - 2026-11-15 07:47:14 --> Controller Class Initialized
DEBUG - 2026-11-15 07:47:14 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:47:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:47:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/attendence.php
INFO - 2026-11-15 07:47:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:47:14 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:14 --> Total execution time: 0.2506
INFO - 2026-11-15 07:47:22 --> Config Class Initialized
INFO - 2026-11-15 07:47:22 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:22 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:22 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:22 --> URI Class Initialized
INFO - 2026-11-15 07:47:22 --> Router Class Initialized
INFO - 2026-11-15 07:47:22 --> Output Class Initialized
INFO - 2026-11-15 07:47:22 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:22 --> Input Class Initialized
INFO - 2026-11-15 07:47:22 --> Language Class Initialized
INFO - 2026-11-15 07:47:22 --> Loader Class Initialized
INFO - 2026-11-15 07:47:22 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:22 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:22 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:22 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:22 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:22 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:22 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:22 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:22 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:22 --> Model "Common" initialized
INFO - 2026-11-15 07:47:22 --> Controller Class Initialized
INFO - 2026-11-15 07:47:22 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 12:47:22 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence_portal.php
INFO - 2026-11-15 12:47:22 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/profile_update_portal.php
INFO - 2026-11-15 12:47:22 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/dashboard.php
INFO - 2026-11-15 12:47:22 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 12:47:22 --> Final output sent to browser
DEBUG - 2026-11-15 12:47:22 --> Total execution time: 0.1781
INFO - 2026-11-15 07:47:25 --> Config Class Initialized
INFO - 2026-11-15 07:47:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:25 --> URI Class Initialized
INFO - 2026-11-15 07:47:25 --> Router Class Initialized
INFO - 2026-11-15 07:47:25 --> Output Class Initialized
INFO - 2026-11-15 07:47:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:25 --> Input Class Initialized
INFO - 2026-11-15 07:47:25 --> Language Class Initialized
INFO - 2026-11-15 07:47:25 --> Loader Class Initialized
INFO - 2026-11-15 07:47:25 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:25 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:25 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:25 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:25 --> Model "Common" initialized
INFO - 2026-11-15 07:47:25 --> Controller Class Initialized
INFO - 2026-11-15 07:47:25 --> Config Class Initialized
INFO - 2026-11-15 07:47:25 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:25 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:25 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:25 --> URI Class Initialized
INFO - 2026-11-15 07:47:25 --> Router Class Initialized
INFO - 2026-11-15 07:47:25 --> Output Class Initialized
INFO - 2026-11-15 07:47:25 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:25 --> Input Class Initialized
INFO - 2026-11-15 07:47:25 --> Language Class Initialized
INFO - 2026-11-15 07:47:25 --> Loader Class Initialized
INFO - 2026-11-15 07:47:25 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:25 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:25 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:25 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:25 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:25 --> Model "Common" initialized
INFO - 2026-11-15 07:47:25 --> Controller Class Initialized
DEBUG - 2026-11-15 07:47:25 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:47:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:47:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/attendence.php
INFO - 2026-11-15 07:47:25 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:47:25 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:25 --> Total execution time: 0.1297
INFO - 2026-11-15 07:47:30 --> Config Class Initialized
INFO - 2026-11-15 07:47:30 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:30 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:30 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:30 --> URI Class Initialized
INFO - 2026-11-15 07:47:30 --> Router Class Initialized
INFO - 2026-11-15 07:47:30 --> Output Class Initialized
INFO - 2026-11-15 07:47:30 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:30 --> Input Class Initialized
INFO - 2026-11-15 07:47:30 --> Language Class Initialized
INFO - 2026-11-15 07:47:30 --> Loader Class Initialized
INFO - 2026-11-15 07:47:30 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:30 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:30 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:30 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:30 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:30 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:30 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:30 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:30 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:30 --> Model "Common" initialized
INFO - 2026-11-15 07:47:30 --> Controller Class Initialized
DEBUG - 2026-11-15 07:47:30 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:47:30 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:47:30 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/movements_list.php
INFO - 2026-11-15 07:47:30 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:47:30 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:30 --> Total execution time: 0.1517
INFO - 2026-11-15 07:47:33 --> Config Class Initialized
INFO - 2026-11-15 07:47:33 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:33 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:33 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:33 --> URI Class Initialized
INFO - 2026-11-15 07:47:33 --> Router Class Initialized
INFO - 2026-11-15 07:47:33 --> Output Class Initialized
INFO - 2026-11-15 07:47:33 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:33 --> Input Class Initialized
INFO - 2026-11-15 07:47:33 --> Language Class Initialized
INFO - 2026-11-15 07:47:33 --> Loader Class Initialized
INFO - 2026-11-15 07:47:33 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:33 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:33 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:34 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:34 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:34 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:34 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:34 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:34 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:34 --> Model "Common" initialized
INFO - 2026-11-15 07:47:34 --> Controller Class Initialized
INFO - 2026-11-15 07:47:34 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:47:34 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/set_movements.php
INFO - 2026-11-15 07:47:34 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:47:34 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:34 --> Total execution time: 0.1495
INFO - 2026-11-15 07:47:44 --> Config Class Initialized
INFO - 2026-11-15 07:47:44 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:47:44 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:47:44 --> Utf8 Class Initialized
INFO - 2026-11-15 07:47:44 --> URI Class Initialized
INFO - 2026-11-15 07:47:44 --> Router Class Initialized
INFO - 2026-11-15 07:47:44 --> Output Class Initialized
INFO - 2026-11-15 07:47:44 --> Security Class Initialized
DEBUG - 2026-11-15 07:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:47:44 --> Input Class Initialized
INFO - 2026-11-15 07:47:44 --> Language Class Initialized
INFO - 2026-11-15 07:47:44 --> Loader Class Initialized
INFO - 2026-11-15 07:47:44 --> Helper loaded: url_helper
INFO - 2026-11-15 07:47:44 --> Helper loaded: form_helper
INFO - 2026-11-15 07:47:44 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:47:44 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:47:44 --> Helper loaded: language_helper
INFO - 2026-11-15 07:47:44 --> Helper loaded: file_helper
INFO - 2026-11-15 07:47:44 --> Database Driver Class Initialized
INFO - 2026-11-15 07:47:44 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:47:44 --> Pagination Class Initialized
INFO - 2026-11-15 07:47:44 --> Model "Common" initialized
INFO - 2026-11-15 07:47:44 --> Controller Class Initialized
INFO - 2026-11-15 07:47:44 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:47:44 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/set_movements.php
INFO - 2026-11-15 07:47:44 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:47:44 --> Final output sent to browser
DEBUG - 2026-11-15 07:47:44 --> Total execution time: 0.1683
INFO - 2026-11-15 07:48:09 --> Config Class Initialized
INFO - 2026-11-15 07:48:09 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:09 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:09 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:09 --> URI Class Initialized
INFO - 2026-11-15 07:48:09 --> Router Class Initialized
INFO - 2026-11-15 07:48:09 --> Output Class Initialized
INFO - 2026-11-15 07:48:09 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:09 --> Input Class Initialized
INFO - 2026-11-15 07:48:09 --> Language Class Initialized
INFO - 2026-11-15 07:48:09 --> Loader Class Initialized
INFO - 2026-11-15 07:48:09 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:09 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:09 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:09 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:09 --> Model "Common" initialized
INFO - 2026-11-15 07:48:09 --> Controller Class Initialized
INFO - 2026-11-15 07:48:09 --> Config Class Initialized
INFO - 2026-11-15 07:48:09 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:09 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:09 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:09 --> URI Class Initialized
INFO - 2026-11-15 07:48:09 --> Router Class Initialized
INFO - 2026-11-15 07:48:09 --> Output Class Initialized
INFO - 2026-11-15 07:48:09 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:09 --> Input Class Initialized
INFO - 2026-11-15 07:48:09 --> Language Class Initialized
INFO - 2026-11-15 07:48:09 --> Loader Class Initialized
INFO - 2026-11-15 07:48:09 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:09 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:09 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:09 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:09 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:09 --> Model "Common" initialized
INFO - 2026-11-15 07:48:09 --> Controller Class Initialized
DEBUG - 2026-11-15 07:48:09 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:48:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:48:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/movements_list.php
INFO - 2026-11-15 07:48:09 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:48:09 --> Final output sent to browser
DEBUG - 2026-11-15 07:48:09 --> Total execution time: 0.1088
INFO - 2026-11-15 07:48:12 --> Config Class Initialized
INFO - 2026-11-15 07:48:12 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:12 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:12 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:12 --> URI Class Initialized
INFO - 2026-11-15 07:48:12 --> Router Class Initialized
INFO - 2026-11-15 07:48:12 --> Output Class Initialized
INFO - 2026-11-15 07:48:12 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:12 --> Input Class Initialized
INFO - 2026-11-15 07:48:12 --> Language Class Initialized
INFO - 2026-11-15 07:48:12 --> Loader Class Initialized
INFO - 2026-11-15 07:48:12 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:12 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:12 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:12 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:12 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:12 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:12 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:12 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:12 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:12 --> Model "Common" initialized
INFO - 2026-11-15 07:48:12 --> Controller Class Initialized
INFO - 2026-11-15 07:48:12 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 12:48:12 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence_portal.php
INFO - 2026-11-15 12:48:12 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/profile_update_portal.php
INFO - 2026-11-15 12:48:12 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/dashboard.php
INFO - 2026-11-15 12:48:12 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 12:48:12 --> Final output sent to browser
DEBUG - 2026-11-15 12:48:12 --> Total execution time: 0.1649
INFO - 2026-11-15 07:48:15 --> Config Class Initialized
INFO - 2026-11-15 07:48:15 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:15 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:15 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:15 --> URI Class Initialized
INFO - 2026-11-15 07:48:15 --> Router Class Initialized
INFO - 2026-11-15 07:48:15 --> Output Class Initialized
INFO - 2026-11-15 07:48:15 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:15 --> Input Class Initialized
INFO - 2026-11-15 07:48:15 --> Language Class Initialized
INFO - 2026-11-15 07:48:15 --> Loader Class Initialized
INFO - 2026-11-15 07:48:15 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:15 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:15 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:15 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:15 --> Model "Common" initialized
INFO - 2026-11-15 07:48:15 --> Controller Class Initialized
INFO - 2026-11-15 07:48:15 --> Config Class Initialized
INFO - 2026-11-15 07:48:15 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:15 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:15 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:15 --> URI Class Initialized
INFO - 2026-11-15 07:48:15 --> Router Class Initialized
INFO - 2026-11-15 07:48:15 --> Output Class Initialized
INFO - 2026-11-15 07:48:15 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:15 --> Input Class Initialized
INFO - 2026-11-15 07:48:15 --> Language Class Initialized
INFO - 2026-11-15 07:48:15 --> Loader Class Initialized
INFO - 2026-11-15 07:48:15 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:15 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:15 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:15 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:15 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:15 --> Model "Common" initialized
INFO - 2026-11-15 07:48:15 --> Controller Class Initialized
DEBUG - 2026-11-15 07:48:15 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:48:15 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:48:15 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/movements_list.php
INFO - 2026-11-15 07:48:15 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:48:15 --> Final output sent to browser
DEBUG - 2026-11-15 07:48:15 --> Total execution time: 0.1174
INFO - 2026-11-15 07:48:21 --> Config Class Initialized
INFO - 2026-11-15 07:48:21 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:21 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:21 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:21 --> URI Class Initialized
INFO - 2026-11-15 07:48:21 --> Router Class Initialized
INFO - 2026-11-15 07:48:21 --> Output Class Initialized
INFO - 2026-11-15 07:48:21 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:21 --> Input Class Initialized
INFO - 2026-11-15 07:48:21 --> Language Class Initialized
INFO - 2026-11-15 07:48:21 --> Loader Class Initialized
INFO - 2026-11-15 07:48:21 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:21 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:21 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:21 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:21 --> Model "Common" initialized
INFO - 2026-11-15 07:48:21 --> Controller Class Initialized
INFO - 2026-11-15 07:48:21 --> Config Class Initialized
INFO - 2026-11-15 07:48:21 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:21 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:21 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:21 --> URI Class Initialized
INFO - 2026-11-15 07:48:21 --> Router Class Initialized
INFO - 2026-11-15 07:48:21 --> Output Class Initialized
INFO - 2026-11-15 07:48:21 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:21 --> Input Class Initialized
INFO - 2026-11-15 07:48:21 --> Language Class Initialized
INFO - 2026-11-15 07:48:21 --> Loader Class Initialized
INFO - 2026-11-15 07:48:21 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:21 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:21 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:21 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:21 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:21 --> Model "Common" initialized
INFO - 2026-11-15 07:48:21 --> Controller Class Initialized
DEBUG - 2026-11-15 07:48:21 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:48:21 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:48:21 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/movements_list.php
INFO - 2026-11-15 07:48:21 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:48:21 --> Final output sent to browser
DEBUG - 2026-11-15 07:48:21 --> Total execution time: 0.1253
INFO - 2026-11-15 07:48:24 --> Config Class Initialized
INFO - 2026-11-15 07:48:24 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:24 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:24 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:24 --> URI Class Initialized
INFO - 2026-11-15 07:48:24 --> Router Class Initialized
INFO - 2026-11-15 07:48:24 --> Output Class Initialized
INFO - 2026-11-15 07:48:24 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:24 --> Input Class Initialized
INFO - 2026-11-15 07:48:24 --> Language Class Initialized
INFO - 2026-11-15 07:48:24 --> Loader Class Initialized
INFO - 2026-11-15 07:48:24 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:24 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:24 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:24 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:24 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:24 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:24 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:24 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:24 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:24 --> Model "Common" initialized
INFO - 2026-11-15 07:48:24 --> Controller Class Initialized
INFO - 2026-11-15 07:48:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 12:48:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence_portal.php
INFO - 2026-11-15 12:48:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/profile_update_portal.php
INFO - 2026-11-15 12:48:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/dashboard.php
INFO - 2026-11-15 12:48:24 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 12:48:24 --> Final output sent to browser
DEBUG - 2026-11-15 12:48:24 --> Total execution time: 0.2830
INFO - 2026-11-15 07:48:27 --> Config Class Initialized
INFO - 2026-11-15 07:48:27 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:27 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:27 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:27 --> URI Class Initialized
INFO - 2026-11-15 07:48:27 --> Router Class Initialized
INFO - 2026-11-15 07:48:27 --> Output Class Initialized
INFO - 2026-11-15 07:48:27 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:27 --> Input Class Initialized
INFO - 2026-11-15 07:48:27 --> Language Class Initialized
INFO - 2026-11-15 07:48:27 --> Loader Class Initialized
INFO - 2026-11-15 07:48:27 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:27 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:27 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:27 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:27 --> Model "Common" initialized
INFO - 2026-11-15 07:48:27 --> Controller Class Initialized
INFO - 2026-11-15 07:48:27 --> Config Class Initialized
INFO - 2026-11-15 07:48:27 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:27 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:27 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:27 --> URI Class Initialized
INFO - 2026-11-15 07:48:27 --> Router Class Initialized
INFO - 2026-11-15 07:48:27 --> Output Class Initialized
INFO - 2026-11-15 07:48:27 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:27 --> Input Class Initialized
INFO - 2026-11-15 07:48:27 --> Language Class Initialized
INFO - 2026-11-15 07:48:27 --> Loader Class Initialized
INFO - 2026-11-15 07:48:27 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:27 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:27 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:27 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:27 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:27 --> Model "Common" initialized
INFO - 2026-11-15 07:48:27 --> Controller Class Initialized
DEBUG - 2026-11-15 07:48:27 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:48:27 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:48:27 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/attendence.php
INFO - 2026-11-15 07:48:27 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:48:27 --> Final output sent to browser
DEBUG - 2026-11-15 07:48:27 --> Total execution time: 0.1142
INFO - 2026-11-15 07:48:38 --> Config Class Initialized
INFO - 2026-11-15 07:48:38 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:38 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:38 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:38 --> URI Class Initialized
INFO - 2026-11-15 07:48:38 --> Router Class Initialized
INFO - 2026-11-15 07:48:38 --> Output Class Initialized
INFO - 2026-11-15 07:48:38 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:38 --> Input Class Initialized
INFO - 2026-11-15 07:48:38 --> Language Class Initialized
INFO - 2026-11-15 07:48:38 --> Loader Class Initialized
INFO - 2026-11-15 07:48:38 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:38 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:38 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:38 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:38 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:38 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:38 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:38 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:38 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:38 --> Model "Common" initialized
INFO - 2026-11-15 07:48:38 --> Controller Class Initialized
DEBUG - 2026-11-15 07:48:38 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:48:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:48:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/attendence.php
INFO - 2026-11-15 07:48:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:48:38 --> Final output sent to browser
DEBUG - 2026-11-15 07:48:38 --> Total execution time: 0.1486
INFO - 2026-11-15 07:48:41 --> Config Class Initialized
INFO - 2026-11-15 07:48:41 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:48:41 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:48:41 --> Utf8 Class Initialized
INFO - 2026-11-15 07:48:41 --> URI Class Initialized
INFO - 2026-11-15 07:48:41 --> Router Class Initialized
INFO - 2026-11-15 07:48:41 --> Output Class Initialized
INFO - 2026-11-15 07:48:41 --> Security Class Initialized
DEBUG - 2026-11-15 07:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:48:41 --> Input Class Initialized
INFO - 2026-11-15 07:48:41 --> Language Class Initialized
INFO - 2026-11-15 07:48:41 --> Loader Class Initialized
INFO - 2026-11-15 07:48:41 --> Helper loaded: url_helper
INFO - 2026-11-15 07:48:41 --> Helper loaded: form_helper
INFO - 2026-11-15 07:48:41 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:48:41 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:48:41 --> Helper loaded: language_helper
INFO - 2026-11-15 07:48:41 --> Helper loaded: file_helper
INFO - 2026-11-15 07:48:41 --> Database Driver Class Initialized
INFO - 2026-11-15 07:48:41 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:48:41 --> Pagination Class Initialized
INFO - 2026-11-15 07:48:41 --> Model "Common" initialized
INFO - 2026-11-15 07:48:41 --> Controller Class Initialized
INFO - 2026-11-15 07:48:41 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:49:04 --> Config Class Initialized
INFO - 2026-11-15 07:49:04 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:49:04 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:49:04 --> Utf8 Class Initialized
INFO - 2026-11-15 07:49:04 --> URI Class Initialized
INFO - 2026-11-15 07:49:04 --> Router Class Initialized
INFO - 2026-11-15 07:49:04 --> Output Class Initialized
INFO - 2026-11-15 07:49:04 --> Security Class Initialized
DEBUG - 2026-11-15 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:49:04 --> Input Class Initialized
INFO - 2026-11-15 07:49:04 --> Language Class Initialized
INFO - 2026-11-15 07:49:04 --> Loader Class Initialized
INFO - 2026-11-15 07:49:04 --> Helper loaded: url_helper
INFO - 2026-11-15 07:49:04 --> Helper loaded: form_helper
INFO - 2026-11-15 07:49:04 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:49:04 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:49:04 --> Helper loaded: language_helper
INFO - 2026-11-15 07:49:04 --> Helper loaded: file_helper
INFO - 2026-11-15 07:49:04 --> Database Driver Class Initialized
INFO - 2026-11-15 07:49:04 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:49:04 --> Pagination Class Initialized
INFO - 2026-11-15 07:49:04 --> Model "Common" initialized
INFO - 2026-11-15 07:49:05 --> Controller Class Initialized
INFO - 2026-11-15 07:49:05 --> Upload Class Initialized
INFO - 2026-11-15 07:49:05 --> Config Class Initialized
INFO - 2026-11-15 07:49:05 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:49:05 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:49:05 --> Utf8 Class Initialized
INFO - 2026-11-15 07:49:05 --> URI Class Initialized
INFO - 2026-11-15 07:49:05 --> Router Class Initialized
INFO - 2026-11-15 07:49:05 --> Output Class Initialized
INFO - 2026-11-15 07:49:05 --> Security Class Initialized
DEBUG - 2026-11-15 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:49:05 --> Input Class Initialized
INFO - 2026-11-15 07:49:05 --> Language Class Initialized
INFO - 2026-11-15 07:49:05 --> Loader Class Initialized
INFO - 2026-11-15 07:49:05 --> Helper loaded: url_helper
INFO - 2026-11-15 07:49:05 --> Helper loaded: form_helper
INFO - 2026-11-15 07:49:05 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:49:05 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:49:05 --> Helper loaded: language_helper
INFO - 2026-11-15 07:49:05 --> Helper loaded: file_helper
INFO - 2026-11-15 07:49:05 --> Database Driver Class Initialized
INFO - 2026-11-15 07:49:05 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:49:05 --> Pagination Class Initialized
INFO - 2026-11-15 07:49:05 --> Model "Common" initialized
INFO - 2026-11-15 07:49:05 --> Controller Class Initialized
DEBUG - 2026-11-15 07:49:05 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:49:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:49:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/movements_list.php
INFO - 2026-11-15 07:49:05 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:49:05 --> Final output sent to browser
DEBUG - 2026-11-15 07:49:05 --> Total execution time: 0.1492
INFO - 2026-11-15 07:49:23 --> Config Class Initialized
INFO - 2026-11-15 07:49:23 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:49:23 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:49:23 --> Utf8 Class Initialized
INFO - 2026-11-15 07:49:23 --> URI Class Initialized
INFO - 2026-11-15 07:49:23 --> Router Class Initialized
INFO - 2026-11-15 07:49:23 --> Output Class Initialized
INFO - 2026-11-15 07:49:23 --> Security Class Initialized
DEBUG - 2026-11-15 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:49:23 --> Input Class Initialized
INFO - 2026-11-15 07:49:23 --> Language Class Initialized
INFO - 2026-11-15 07:49:23 --> Loader Class Initialized
INFO - 2026-11-15 07:49:23 --> Helper loaded: url_helper
INFO - 2026-11-15 07:49:23 --> Helper loaded: form_helper
INFO - 2026-11-15 07:49:23 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:49:23 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:49:23 --> Helper loaded: language_helper
INFO - 2026-11-15 07:49:23 --> Helper loaded: file_helper
INFO - 2026-11-15 07:49:23 --> Database Driver Class Initialized
INFO - 2026-11-15 07:49:23 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:49:23 --> Pagination Class Initialized
INFO - 2026-11-15 07:49:23 --> Model "Common" initialized
INFO - 2026-11-15 07:49:23 --> Controller Class Initialized
INFO - 2026-11-15 07:49:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:49:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/leave_appication_form.php
INFO - 2026-11-15 07:49:23 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:49:23 --> Final output sent to browser
DEBUG - 2026-11-15 07:49:23 --> Total execution time: 0.1523
INFO - 2026-11-15 07:49:33 --> Config Class Initialized
INFO - 2026-11-15 07:49:33 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:49:33 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:49:33 --> Utf8 Class Initialized
INFO - 2026-11-15 07:49:33 --> URI Class Initialized
INFO - 2026-11-15 07:49:33 --> Router Class Initialized
INFO - 2026-11-15 07:49:33 --> Output Class Initialized
INFO - 2026-11-15 07:49:33 --> Security Class Initialized
DEBUG - 2026-11-15 07:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:49:33 --> Input Class Initialized
INFO - 2026-11-15 07:49:33 --> Language Class Initialized
INFO - 2026-11-15 07:49:33 --> Loader Class Initialized
INFO - 2026-11-15 07:49:33 --> Helper loaded: url_helper
INFO - 2026-11-15 07:49:33 --> Helper loaded: form_helper
INFO - 2026-11-15 07:49:33 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:49:33 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:49:33 --> Helper loaded: language_helper
INFO - 2026-11-15 07:49:33 --> Helper loaded: file_helper
INFO - 2026-11-15 07:49:33 --> Database Driver Class Initialized
INFO - 2026-11-15 07:49:33 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:49:33 --> Pagination Class Initialized
INFO - 2026-11-15 07:49:33 --> Model "Common" initialized
INFO - 2026-11-15 07:49:33 --> Controller Class Initialized
DEBUG - 2026-11-15 07:49:33 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:49:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:49:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/leave_application_list.php
INFO - 2026-11-15 07:49:33 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:49:33 --> Final output sent to browser
DEBUG - 2026-11-15 07:49:33 --> Total execution time: 0.1484
INFO - 2026-11-15 07:49:50 --> Config Class Initialized
INFO - 2026-11-15 07:49:50 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:49:50 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:49:50 --> Utf8 Class Initialized
INFO - 2026-11-15 07:49:50 --> URI Class Initialized
INFO - 2026-11-15 07:49:50 --> Router Class Initialized
INFO - 2026-11-15 07:49:50 --> Output Class Initialized
INFO - 2026-11-15 07:49:50 --> Security Class Initialized
DEBUG - 2026-11-15 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:49:50 --> Input Class Initialized
INFO - 2026-11-15 07:49:50 --> Language Class Initialized
INFO - 2026-11-15 07:49:50 --> Loader Class Initialized
INFO - 2026-11-15 07:49:50 --> Helper loaded: url_helper
INFO - 2026-11-15 07:49:50 --> Helper loaded: form_helper
INFO - 2026-11-15 07:49:50 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:49:50 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:49:50 --> Helper loaded: language_helper
INFO - 2026-11-15 07:49:50 --> Helper loaded: file_helper
INFO - 2026-11-15 07:49:50 --> Database Driver Class Initialized
INFO - 2026-11-15 07:49:50 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:49:50 --> Pagination Class Initialized
INFO - 2026-11-15 07:49:50 --> Model "Common" initialized
INFO - 2026-11-15 07:49:50 --> Controller Class Initialized
INFO - 2026-11-15 07:49:50 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:49:50 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/leave_appication_form.php
INFO - 2026-11-15 07:49:50 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:49:50 --> Final output sent to browser
DEBUG - 2026-11-15 07:49:50 --> Total execution time: 0.1445
INFO - 2026-11-15 07:50:43 --> Config Class Initialized
INFO - 2026-11-15 07:50:43 --> Hooks Class Initialized
DEBUG - 2026-11-15 07:50:43 --> UTF-8 Support Enabled
INFO - 2026-11-15 07:50:43 --> Utf8 Class Initialized
INFO - 2026-11-15 07:50:43 --> URI Class Initialized
INFO - 2026-11-15 07:50:43 --> Router Class Initialized
INFO - 2026-11-15 07:50:43 --> Output Class Initialized
INFO - 2026-11-15 07:50:43 --> Security Class Initialized
DEBUG - 2026-11-15 07:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 07:50:43 --> Input Class Initialized
INFO - 2026-11-15 07:50:43 --> Language Class Initialized
INFO - 2026-11-15 07:50:43 --> Loader Class Initialized
INFO - 2026-11-15 07:50:43 --> Helper loaded: url_helper
INFO - 2026-11-15 07:50:43 --> Helper loaded: form_helper
INFO - 2026-11-15 07:50:43 --> Helper loaded: hand_helper
INFO - 2026-11-15 07:50:43 --> Helper loaded: menu_helper
INFO - 2026-11-15 07:50:43 --> Helper loaded: language_helper
INFO - 2026-11-15 07:50:43 --> Helper loaded: file_helper
INFO - 2026-11-15 07:50:43 --> Database Driver Class Initialized
INFO - 2026-11-15 07:50:43 --> Form Validation Class Initialized
DEBUG - 2026-11-15 07:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 07:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 07:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 07:50:43 --> Pagination Class Initialized
INFO - 2026-11-15 07:50:43 --> Model "Common" initialized
INFO - 2026-11-15 07:50:43 --> Controller Class Initialized
DEBUG - 2026-11-15 07:50:43 --> Pagination class already loaded. Second attempt ignored.
INFO - 2026-11-15 07:50:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/side_menu.php
INFO - 2026-11-15 07:50:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/attendence/leave_application_list.php
INFO - 2026-11-15 07:50:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\user_dashboard/master_layout.php
INFO - 2026-11-15 07:50:43 --> Final output sent to browser
DEBUG - 2026-11-15 07:50:43 --> Total execution time: 0.3243
INFO - 2026-11-15 08:11:38 --> Config Class Initialized
INFO - 2026-11-15 08:11:38 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:38 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:38 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:38 --> URI Class Initialized
INFO - 2026-11-15 08:11:38 --> Router Class Initialized
INFO - 2026-11-15 08:11:38 --> Output Class Initialized
INFO - 2026-11-15 08:11:38 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:38 --> Input Class Initialized
INFO - 2026-11-15 08:11:38 --> Language Class Initialized
INFO - 2026-11-15 08:11:38 --> Loader Class Initialized
INFO - 2026-11-15 08:11:38 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:38 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:38 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:38 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:38 --> Model "Common" initialized
INFO - 2026-11-15 08:11:38 --> Controller Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2026-11-15 08:11:38 --> Language file loaded: language/bangla/site_lang.php
INFO - 2026-11-15 08:11:38 --> Config Class Initialized
INFO - 2026-11-15 08:11:38 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:38 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:38 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:38 --> URI Class Initialized
INFO - 2026-11-15 08:11:38 --> Router Class Initialized
INFO - 2026-11-15 08:11:38 --> Output Class Initialized
INFO - 2026-11-15 08:11:38 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:38 --> Input Class Initialized
INFO - 2026-11-15 08:11:38 --> Language Class Initialized
INFO - 2026-11-15 08:11:38 --> Loader Class Initialized
INFO - 2026-11-15 08:11:38 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:38 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:38 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:38 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:38 --> Model "Common" initialized
INFO - 2026-11-15 08:11:38 --> Controller Class Initialized
INFO - 2026-11-15 08:11:38 --> Config Class Initialized
INFO - 2026-11-15 08:11:38 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:38 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:38 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:38 --> URI Class Initialized
INFO - 2026-11-15 08:11:38 --> Router Class Initialized
INFO - 2026-11-15 08:11:38 --> Output Class Initialized
INFO - 2026-11-15 08:11:38 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:38 --> Input Class Initialized
INFO - 2026-11-15 08:11:38 --> Language Class Initialized
INFO - 2026-11-15 08:11:38 --> Loader Class Initialized
INFO - 2026-11-15 08:11:38 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:38 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:38 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:38 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:38 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:38 --> Model "Common" initialized
INFO - 2026-11-15 08:11:38 --> Controller Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2026-11-15 08:11:38 --> Language file loaded: language/bangla/site_lang.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/home_page_header.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/navbar.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/news_headline.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/header.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/footer.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/pages/user_registration/user_login_form.php
INFO - 2026-11-15 08:11:38 --> File loaded: C:\xampp\htdocs\ctl3\application\views\site/master_layout.php
INFO - 2026-11-15 08:11:38 --> Final output sent to browser
DEBUG - 2026-11-15 08:11:38 --> Total execution time: 0.1525
INFO - 2026-11-15 08:11:38 --> Config Class Initialized
INFO - 2026-11-15 08:11:38 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:38 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:38 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:38 --> URI Class Initialized
INFO - 2026-11-15 08:11:38 --> Router Class Initialized
INFO - 2026-11-15 08:11:38 --> Output Class Initialized
INFO - 2026-11-15 08:11:38 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:38 --> Input Class Initialized
INFO - 2026-11-15 08:11:38 --> Language Class Initialized
ERROR - 2026-11-15 08:11:38 --> 404 Page Not Found: Stylecss/index
INFO - 2026-11-15 08:11:42 --> Config Class Initialized
INFO - 2026-11-15 08:11:42 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:43 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:43 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:43 --> URI Class Initialized
INFO - 2026-11-15 08:11:43 --> Router Class Initialized
INFO - 2026-11-15 08:11:43 --> Output Class Initialized
INFO - 2026-11-15 08:11:43 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:43 --> Input Class Initialized
INFO - 2026-11-15 08:11:43 --> Language Class Initialized
INFO - 2026-11-15 08:11:43 --> Loader Class Initialized
INFO - 2026-11-15 08:11:43 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:43 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:43 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:43 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:43 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:43 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:43 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:43 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:43 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:43 --> Model "Common" initialized
INFO - 2026-11-15 08:11:43 --> Controller Class Initialized
INFO - 2026-11-15 08:11:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/header.php
INFO - 2026-11-15 08:11:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/footer.php
INFO - 2026-11-15 08:11:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\login/login.php
INFO - 2026-11-15 08:11:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\recruitment/master_layout.php
INFO - 2026-11-15 08:11:43 --> Final output sent to browser
DEBUG - 2026-11-15 08:11:43 --> Total execution time: 0.1411
INFO - 2026-11-15 08:11:44 --> Config Class Initialized
INFO - 2026-11-15 08:11:44 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:44 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:44 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:44 --> URI Class Initialized
INFO - 2026-11-15 08:11:44 --> Router Class Initialized
INFO - 2026-11-15 08:11:44 --> Output Class Initialized
INFO - 2026-11-15 08:11:44 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:44 --> Input Class Initialized
INFO - 2026-11-15 08:11:44 --> Language Class Initialized
INFO - 2026-11-15 08:11:44 --> Loader Class Initialized
INFO - 2026-11-15 08:11:44 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:44 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:44 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:44 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:45 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:45 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:45 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:45 --> Model "Common" initialized
INFO - 2026-11-15 08:11:45 --> Controller Class Initialized
INFO - 2026-11-15 08:11:45 --> Config Class Initialized
INFO - 2026-11-15 08:11:45 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:11:45 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:11:45 --> Utf8 Class Initialized
INFO - 2026-11-15 08:11:45 --> URI Class Initialized
INFO - 2026-11-15 08:11:45 --> Router Class Initialized
INFO - 2026-11-15 08:11:45 --> Output Class Initialized
INFO - 2026-11-15 08:11:45 --> Security Class Initialized
DEBUG - 2026-11-15 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:11:45 --> Input Class Initialized
INFO - 2026-11-15 08:11:45 --> Language Class Initialized
INFO - 2026-11-15 08:11:45 --> Loader Class Initialized
INFO - 2026-11-15 08:11:45 --> Helper loaded: url_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: form_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: language_helper
INFO - 2026-11-15 08:11:45 --> Helper loaded: file_helper
INFO - 2026-11-15 08:11:45 --> Database Driver Class Initialized
INFO - 2026-11-15 08:11:45 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:11:45 --> Pagination Class Initialized
INFO - 2026-11-15 08:11:45 --> Model "Common" initialized
INFO - 2026-11-15 08:11:45 --> Controller Class Initialized
INFO - 2026-11-15 08:11:45 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:11:45 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:11:45 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:11:45 --> Final output sent to browser
DEBUG - 2026-11-15 08:11:45 --> Total execution time: 0.1568
INFO - 2026-11-15 08:13:17 --> Config Class Initialized
INFO - 2026-11-15 08:13:17 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:13:17 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:13:17 --> Utf8 Class Initialized
INFO - 2026-11-15 08:13:17 --> URI Class Initialized
INFO - 2026-11-15 08:13:17 --> Router Class Initialized
INFO - 2026-11-15 08:13:17 --> Output Class Initialized
INFO - 2026-11-15 08:13:17 --> Security Class Initialized
DEBUG - 2026-11-15 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:13:17 --> Input Class Initialized
INFO - 2026-11-15 08:13:17 --> Language Class Initialized
INFO - 2026-11-15 08:13:17 --> Loader Class Initialized
INFO - 2026-11-15 08:13:17 --> Helper loaded: url_helper
INFO - 2026-11-15 08:13:17 --> Helper loaded: form_helper
INFO - 2026-11-15 08:13:17 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:13:17 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:13:17 --> Helper loaded: language_helper
INFO - 2026-11-15 08:13:17 --> Helper loaded: file_helper
INFO - 2026-11-15 08:13:17 --> Database Driver Class Initialized
INFO - 2026-11-15 08:13:17 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:13:17 --> Pagination Class Initialized
INFO - 2026-11-15 08:13:17 --> Model "Common" initialized
INFO - 2026-11-15 08:13:17 --> Controller Class Initialized
INFO - 2026-11-15 08:13:17 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:13:17 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:13:17 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:13:17 --> Final output sent to browser
DEBUG - 2026-11-15 08:13:17 --> Total execution time: 0.2094
INFO - 2026-11-15 08:13:52 --> Config Class Initialized
INFO - 2026-11-15 08:13:52 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:13:52 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:13:52 --> Utf8 Class Initialized
INFO - 2026-11-15 08:13:52 --> URI Class Initialized
INFO - 2026-11-15 08:13:52 --> Router Class Initialized
INFO - 2026-11-15 08:13:52 --> Output Class Initialized
INFO - 2026-11-15 08:13:52 --> Security Class Initialized
DEBUG - 2026-11-15 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:13:52 --> Input Class Initialized
INFO - 2026-11-15 08:13:52 --> Language Class Initialized
INFO - 2026-11-15 08:13:52 --> Loader Class Initialized
INFO - 2026-11-15 08:13:52 --> Helper loaded: url_helper
INFO - 2026-11-15 08:13:52 --> Helper loaded: form_helper
INFO - 2026-11-15 08:13:52 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:13:52 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:13:52 --> Helper loaded: language_helper
INFO - 2026-11-15 08:13:52 --> Helper loaded: file_helper
INFO - 2026-11-15 08:13:52 --> Database Driver Class Initialized
INFO - 2026-11-15 08:13:52 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:13:52 --> Pagination Class Initialized
INFO - 2026-11-15 08:13:52 --> Model "Common" initialized
INFO - 2026-11-15 08:13:52 --> Controller Class Initialized
INFO - 2026-11-15 08:13:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:13:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:13:53 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:13:53 --> Final output sent to browser
DEBUG - 2026-11-15 08:13:53 --> Total execution time: 0.4803
INFO - 2026-11-15 08:14:14 --> Config Class Initialized
INFO - 2026-11-15 08:14:14 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:14:14 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:14:14 --> Utf8 Class Initialized
INFO - 2026-11-15 08:14:14 --> URI Class Initialized
INFO - 2026-11-15 08:14:14 --> Router Class Initialized
INFO - 2026-11-15 08:14:14 --> Output Class Initialized
INFO - 2026-11-15 08:14:14 --> Security Class Initialized
DEBUG - 2026-11-15 08:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:14:14 --> Input Class Initialized
INFO - 2026-11-15 08:14:14 --> Language Class Initialized
INFO - 2026-11-15 08:14:14 --> Loader Class Initialized
INFO - 2026-11-15 08:14:14 --> Helper loaded: url_helper
INFO - 2026-11-15 08:14:14 --> Helper loaded: form_helper
INFO - 2026-11-15 08:14:14 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:14:14 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:14:14 --> Helper loaded: language_helper
INFO - 2026-11-15 08:14:14 --> Helper loaded: file_helper
INFO - 2026-11-15 08:14:14 --> Database Driver Class Initialized
INFO - 2026-11-15 08:14:14 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:14:14 --> Pagination Class Initialized
INFO - 2026-11-15 08:14:14 --> Model "Common" initialized
INFO - 2026-11-15 08:14:14 --> Controller Class Initialized
INFO - 2026-11-15 08:14:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:14:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:14:14 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:14:14 --> Final output sent to browser
DEBUG - 2026-11-15 08:14:14 --> Total execution time: 0.2257
INFO - 2026-11-15 08:14:26 --> Config Class Initialized
INFO - 2026-11-15 08:14:26 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:14:26 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:14:26 --> Utf8 Class Initialized
INFO - 2026-11-15 08:14:26 --> URI Class Initialized
INFO - 2026-11-15 08:14:26 --> Router Class Initialized
INFO - 2026-11-15 08:14:26 --> Output Class Initialized
INFO - 2026-11-15 08:14:26 --> Security Class Initialized
DEBUG - 2026-11-15 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:14:26 --> Input Class Initialized
INFO - 2026-11-15 08:14:26 --> Language Class Initialized
INFO - 2026-11-15 08:14:26 --> Loader Class Initialized
INFO - 2026-11-15 08:14:26 --> Helper loaded: url_helper
INFO - 2026-11-15 08:14:26 --> Helper loaded: form_helper
INFO - 2026-11-15 08:14:26 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:14:26 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:14:26 --> Helper loaded: language_helper
INFO - 2026-11-15 08:14:26 --> Helper loaded: file_helper
INFO - 2026-11-15 08:14:26 --> Database Driver Class Initialized
INFO - 2026-11-15 08:14:26 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:14:26 --> Pagination Class Initialized
INFO - 2026-11-15 08:14:26 --> Model "Common" initialized
INFO - 2026-11-15 08:14:26 --> Controller Class Initialized
INFO - 2026-11-15 08:14:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:14:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:14:26 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:14:26 --> Final output sent to browser
DEBUG - 2026-11-15 08:14:26 --> Total execution time: 0.6819
INFO - 2026-11-15 08:14:43 --> Config Class Initialized
INFO - 2026-11-15 08:14:43 --> Hooks Class Initialized
DEBUG - 2026-11-15 08:14:43 --> UTF-8 Support Enabled
INFO - 2026-11-15 08:14:43 --> Utf8 Class Initialized
INFO - 2026-11-15 08:14:43 --> URI Class Initialized
INFO - 2026-11-15 08:14:43 --> Router Class Initialized
INFO - 2026-11-15 08:14:43 --> Output Class Initialized
INFO - 2026-11-15 08:14:43 --> Security Class Initialized
DEBUG - 2026-11-15 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2026-11-15 08:14:43 --> Input Class Initialized
INFO - 2026-11-15 08:14:43 --> Language Class Initialized
INFO - 2026-11-15 08:14:43 --> Loader Class Initialized
INFO - 2026-11-15 08:14:43 --> Helper loaded: url_helper
INFO - 2026-11-15 08:14:43 --> Helper loaded: form_helper
INFO - 2026-11-15 08:14:43 --> Helper loaded: hand_helper
INFO - 2026-11-15 08:14:43 --> Helper loaded: menu_helper
INFO - 2026-11-15 08:14:43 --> Helper loaded: language_helper
INFO - 2026-11-15 08:14:43 --> Helper loaded: file_helper
INFO - 2026-11-15 08:14:43 --> Database Driver Class Initialized
INFO - 2026-11-15 08:14:43 --> Form Validation Class Initialized
DEBUG - 2026-11-15 08:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2026-11-15 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2026-11-15 08:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2026-11-15 08:14:43 --> Pagination Class Initialized
INFO - 2026-11-15 08:14:43 --> Model "Common" initialized
INFO - 2026-11-15 08:14:43 --> Controller Class Initialized
INFO - 2026-11-15 08:14:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/side_menu.php
INFO - 2026-11-15 08:14:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/dashboard.php
INFO - 2026-11-15 08:14:43 --> File loaded: C:\xampp\htdocs\ctl3\application\views\admin/master_layout.php
INFO - 2026-11-15 08:14:43 --> Final output sent to browser
DEBUG - 2026-11-15 08:14:43 --> Total execution time: 0.1945
