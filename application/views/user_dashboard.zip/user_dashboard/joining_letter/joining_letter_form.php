<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
    .appointment-wrapper {
        background: #f4f6f9;
        min-height: 100vh;
        padding: 30px 0;
    }

    .appointment-card {
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 12px;
        box-shadow: 0 4px 18px rgba(15, 23, 42, .04);
        overflow: hidden;
        margin-bottom: 24px;
    }

    .appointment-card-header {
        padding: 20px 25px;
        border-bottom: 1px solid #e9ecef;
        background: #fff;
    }

    .appointment-card-body {
        padding: 25px;
    }

    .section-icon {
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 9px;
        background: #eaf2ff;
        color: #0d6efd;
        font-size: 19px;
        flex-shrink: 0;
    }

    .form-label {
        font-weight: 600;
        color: #374151;
        font-size: 13px;
        margin-bottom: 8px;
    }

    .form-control,
    .form-select {
        min-height: 44px;
        border: 1px solid #dce1e8;
        border-radius: 7px;
        font-size: 14px;
    }

    textarea.form-control {
        min-height: 120px;
        resize: vertical;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 3px rgba(13, 110, 253, .10);
    }

    .required {
        color: #dc3545;
    }

    .form-help {
        color: #6b7280;
        font-size: 12px;
        margin-top: 5px;
    }

    .appointment-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
        padding: 20px 25px;
        background: #fff;
        border-top: 1px solid #e9ecef;
    }

    .btn-save {
        padding: 10px 22px;
        font-weight: 600;
        border-radius: 7px;
    }

    .section-description {
        font-size: 13px;
        color: #6b7280;
        margin: 5px 0 0;
    }

    @media (max-width: 576px) {

        .appointment-card-body,
        .appointment-card-header,
        .appointment-footer {
            padding: 18px;
        }
    }
</style>

<div class="content-wrapper appointment-wrapper">
    <div class="container-fluid px-3 px-lg-4">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <div class="d-flex align-items-center gap-3">
                    <div class="section-icon">
                        <i class="bi bi-file-earmark-text"></i>
                    </div>
                    <div>
                        <h2 class="h4 fw-bold mb-1">Create Joining Letter</h2>

                    </div>
                </div>
            </div>
        </div>

        <form action="<?= base_url('joining_letter_save/') ?>" method="POST" id="appointmentForm"
            enctype="multipart/form-data">

            <div class="appointment-card">
                <div class="appointment-card-header">
                    <div class="d-flex align-items-center gap-3">

                        <div class="appointment-card-header">
                            <div class="d-flex align-items-center gap-3">
                                <div class="section-icon">
                                    <i class="bi bi-briefcase"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold mb-0">Staff's Details</h5>
                                    <p class="section-description">
                                        Specify the information.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="appointment-card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">
                                Name <span class="required">*</span>
                            </label>
                            <input type="text" name="name" class="form-control"
                                value="<?= html_escape($staff_info->staff_name ?? 'N/A'); ?>"
                                placeholder="Enter your full name" required>
                        </div>

                       
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Submitted To <span
                                        class="text-danger">*</span></label>
                                <select name="submitted_to" class="form-select" required>
                                    <option disabled selected>Select</option>
                                    <option value="managing Director">managing Director</option>
                                    
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">
                                    Reference No. <span class="required">*</span>
                                </label>
                                <input type="text" name="reference_no" class="form-control"
                                    value="<?= html_escape($appointment_letter->letter_number ?? 'N/A'); ?>"
                                    placeholder="Enter Appintment Letter no." required>
                            </div>


                            <div class="col-md-6">
                                <label class="form-label">Employee ID<span class="required">*</span></label>
                                <input type="text" name="employee_id" class="form-control"
                                    placeholder="Enter employee ID"
                                    value="<?= html_escape($staff_info->staff_id ?? 'N/A'); ?>" required readonly>
                            </div>



                        </div>
                    </div>
                </div>

                <div class="appointment-card">


                    <div class="appointment-card-body">
                        <div class="row g-3">

                            <div class="col-md-6">
                                <label class="form-label">
                                    Designation / Job Title <span class="required">*</span>
                                </label>
                                <input type="text" name="designation" class="form-control"
                                    placeholder="e.g. Software Engineer"
                                    value="<?= html_escape($staff_info->designation ?? 'N/A'); ?>" required>
                            </div>






                            <div class="col-md-6">
                                <label class="form-label">
                                    Joining Date <span class="required">*</span>
                                </label>
                                <input type="date" name="joining_date" class="form-control" required>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Signature <span class="required">*</span></label>
                                <input type="file" name="signature" class="form-control" placeholder="" required>
                            </div>

                        </div>
                    </div>
                </div>





                <!-- Form Actions -->
                <div class="appointment-card">
                    <div class="appointment-footer">
                        <div class="text-muted small">
                            <i class="bi bi-info-circle me-1"></i>
                            Fields marked <span class="required">*</span> are required.
                        </div>

                        <div class="d-flex gap-2">
                            <button type="reset" class="btn btn-light border">
                                <i class="bi bi-arrow-counterclockwise me-1"></i>
                                Reset
                            </button>

                            <button type="submit" class="btn btn-primary btn-save">
                                <i class="bi bi-check2-circle me-1"></i>
                                Create Appointment Letter
                            </button>
                        </div>
                    </div>
                </div>



        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('appointmentForm');

        form.addEventListener('submit', function (event) {
            const appointmentDate =
                form.querySelector('[name="appointment_date"]').value;

            const joiningDate =
                form.querySelector('[name="joining_date"]').value;

            if (appointmentDate && joiningDate && joiningDate < appointmentDate) {
                event.preventDefault();
                alert('Joining date cannot be earlier than the appointment date.');
                return;
            }
        });
    });
</script>